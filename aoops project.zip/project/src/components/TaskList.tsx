import { Task } from '../types';

interface TaskListProps {
  tasks: Task[];
  onToggleTask: (id: string) => void;
  onDeleteTask: (id: string) => void;
}

export function TaskList({ tasks, onToggleTask, onDeleteTask }: TaskListProps) {
  if (tasks.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        <p>No tasks yet. Try saying "Add task" followed by your task description.</p>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-4 text-sm text-gray-600">
        Total: {tasks.length} | Completed: {tasks.filter(t => t.completed).length}
      </div>
      <ul className="space-y-2">
        {tasks.map((task) => (
          <li
            key={task.id}
            className="flex items-center justify-between bg-white p-4 rounded-lg shadow animate-fade-in hover:shadow-md transition-shadow duration-200"
          >
            <div className="flex items-center space-x-3">
              <div className="relative">
                <input
                  type="checkbox"
                  checked={task.completed}
                  onChange={() => onToggleTask(task.id)}
                  className="h-5 w-5 rounded border-gray-300 transition-colors duration-200"
                />
                {task.completed && (
                  <div className="absolute inset-0 animate-ping rounded-sm border-2 border-blue-500 opacity-75" />
                )}
              </div>
              <span 
                className={`transition-all duration-200 ${
                  task.completed 
                    ? 'line-through text-gray-500 opacity-75' 
                    : 'text-gray-800'
                }`}
              >
                {task.text}
              </span>
            </div>
            <button
              onClick={() => onDeleteTask(task.id)}
              className="text-red-500 hover:text-red-700 transition-colors duration-200 p-2 hover:bg-red-50 rounded-full"
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                className="h-5 w-5" 
                viewBox="0 0 20 20" 
                fill="currentColor"
              >
                <path 
                  fillRule="evenodd" 
                  d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" 
                  clipRule="evenodd" 
                />
              </svg>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}