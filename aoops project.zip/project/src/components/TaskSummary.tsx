import { Task } from '../types';

interface TaskSummaryProps {
  tasks: Task[];
  show: boolean;
}

export function TaskSummary({ tasks, show }: TaskSummaryProps) {
  if (!show) return null;

  const completedTasks = tasks.filter(task => task.completed).length;
  const pendingTasks = tasks.length - completedTasks;

  return (
    <div className="fixed top-4 right-4 bg-white p-4 rounded-lg shadow-lg border border-gray-200 animate-fade-in">
      <h3 className="text-lg font-semibold mb-2">Task Summary</h3>
      <div className="space-y-1">
        <p>Total Tasks: {tasks.length}</p>
        <p>Completed: {completedTasks}</p>
        <p>Pending: {pendingTasks}</p>
      </div>
    </div>
  );
}