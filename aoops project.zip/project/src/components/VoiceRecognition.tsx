import { useState, useEffect, useRef } from 'react';

interface VoiceRecognitionProps {
  onCommand: (command: string) => void;
  isListening: boolean;
}

export function VoiceRecognition({ onCommand, isListening }: VoiceRecognitionProps) {
  const [error, setError] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);
  const isRecognitionActiveRef = useRef(false);

  useEffect(() => {
    try {
      // @ts-ignore
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (!SpeechRecognition) {
        setError('Speech recognition is not supported in this browser');
        return;
      }

      const recognitionInstance = new SpeechRecognition();
      recognitionInstance.continuous = true;
      recognitionInstance.interimResults = false;
      recognitionInstance.lang = 'en-US';

      recognitionInstance.onresult = (event: any) => {
        const last = event.results.length - 1;
        const command = event.results[last][0].transcript;
        console.log('Recognized command:', command);
        onCommand(command.toLowerCase());
      };

      recognitionInstance.onerror = (event: any) => {
        console.error('Speech recognition error:', event);
        if (event.error !== 'no-speech') {
          setError('Error occurred during speech recognition');
        }
        isRecognitionActiveRef.current = false;
      };

      recognitionInstance.onend = () => {
        isRecognitionActiveRef.current = false;
        if (isListening) {
          setTimeout(() => {
            try {
              if (isListening && !isRecognitionActiveRef.current) {
                recognitionInstance.start();
                isRecognitionActiveRef.current = true;
              }
            } catch (err) {
              console.error('Error restarting recognition:', err);
            }
          }, 100);
        }
      };

      recognitionRef.current = recognitionInstance;

      return () => {
        try {
          if (isRecognitionActiveRef.current) {
            recognitionInstance.stop();
            isRecognitionActiveRef.current = false;
          }
        } catch (err) {
          console.error('Error stopping recognition:', err);
        }
      };
    } catch (err) {
      console.error('Error initializing speech recognition:', err);
      setError('Failed to initialize speech recognition');
    }
  }, []);

  useEffect(() => {
    const recognition = recognitionRef.current;
    if (!recognition) return;

    const startRecognition = async () => {
      try {
        if (!isRecognitionActiveRef.current) {
          await recognition.start();
          isRecognitionActiveRef.current = true;
          console.log('Started listening');
        }
      } catch (err) {
        console.error('Error starting recognition:', err);
        isRecognitionActiveRef.current = false;
      }
    };

    const stopRecognition = async () => {
      try {
        if (isRecognitionActiveRef.current) {
          await recognition.stop();
          isRecognitionActiveRef.current = false;
          console.log('Stopped listening');
        }
      } catch (err) {
        console.error('Error stopping recognition:', err);
      }
    };

    if (isListening) {
      startRecognition();
    } else {
      stopRecognition();
    }

    return () => {
      if (isRecognitionActiveRef.current) {
        stopRecognition();
      }
    };
  }, [isListening]);

  if (error) {
    return (
      <div className="text-red-500 text-sm mt-2">
        {error}
      </div>
    );
  }

  return (
    <div className="flex items-center space-x-2">
      <div className="text-sm text-gray-600">
        {isListening ? 'Listening for commands...' : 'Click "Start Listening" to begin'}
      </div>
      {isListening && (
        <div className="relative">
          <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
          <div className="absolute inset-0 w-3 h-3 bg-red-500 rounded-full animate-ping"></div>
        </div>
      )}
    </div>
  );
}