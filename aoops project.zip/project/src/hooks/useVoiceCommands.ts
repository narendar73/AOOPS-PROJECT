import { useCallback } from 'react';
import { Task } from '../types';

export function useVoiceCommands(
  setTasks: React.Dispatch<React.SetStateAction<Task[]>>,
  setShowTaskSummary: React.Dispatch<React.SetStateAction<boolean>>,
  setNotification: (message: string) => void
) {
  const handleCommand = useCallback((command: string) => {
    console.log('Processing command:', command);
    setNotification(`Command detected: "${command}"`);

    if (command.includes('add task')) {
      const taskText = command.replace('add task', '').trim();
      console.log('Adding task:', taskText);
      if (taskText) {
        setTasks((prev) => [
          ...prev,
          {
            id: crypto.randomUUID(),
            text: taskText,
            completed: false,
          },
        ]);
        setNotification(`Added task: "${taskText}"`);
      }
    } else if (command.includes('clear tasks') || command.includes('clear all tasks')) {
      console.log('Clearing all tasks');
      setTasks([]);
      setNotification('Cleared all tasks');
    } else if (command.includes('complete all')) {
      console.log('Completing all tasks');
      setTasks((prev) =>
        prev.map((task) => ({
          ...task,
          completed: true,
        }))
      );
      setNotification('Completed all tasks');
    } else if (command.includes('show tasks') || command.includes('list tasks')) {
      console.log('Showing task summary');
      setShowTaskSummary(true);
      setNotification('Showing task summary');
      setTimeout(() => setShowTaskSummary(false), 5000);
    }
  }, [setTasks, setShowTaskSummary, setNotification]);

  return handleCommand;
}