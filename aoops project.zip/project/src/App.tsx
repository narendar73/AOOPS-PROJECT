import { useState, useCallback, useEffect } from 'react';
import { Task } from './types';
import { VoiceRecognition } from './components/VoiceRecognition';
import { TaskList } from './components/TaskList';
import { TaskSummary } from './components/TaskSummary';
import { Notification } from './components/Notification';
import { useVoiceCommands } from './hooks/useVoiceCommands';
import { KeyboardShortcut } from './components/KeyboardShortcut';

export default function App() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isListening, setIsListening] = useState(false);
  const [showTaskSummary, setShowTaskSummary] = useState(false);
  const [notification, setNotification] = useState({ show: false, message: '' });

  const showNotification = useCallback((message: string) => {
    setNotification({ show: true, message });
  }, []);

  const hideNotification = useCallback(() => {
    setNotification({ show: false, message: '' });
  }, []);

  const handleCommand = useVoiceCommands(setTasks, setShowTaskSummary, showNotification);

  const toggleTask = (id: string) => {
    setTasks((prev) =>
      prev.map((task) =>
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    );
  };

  const deleteTask = (id: string) => {
    setTasks((prev) => prev.filter((task) => task.id !== id));
  };

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.code === 'Space' && e.target === document.body) {
        e.preventDefault();
        setIsListening(prev => !prev);
      }
    };

    document.addEventListener('keydown', handleKeyPress);
    return () => document.removeEventListener('keydown', handleKeyPress);
  }, []);

  return (
    <div className="min-h-screen bg-gray-100 py-8 px-4">
      <TaskSummary tasks={tasks} show={showTaskSummary} />
      <Notification 
        message={notification.message}
        show={notification.show}
        onHide={hideNotification}
      />
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">
            Voice Task Manager
          </h1>
          
          <div className="mb-6 flex items-center justify-between">
            <button
              onClick={() => setIsListening(!isListening)}
              className={`px-6 py-3 rounded-lg font-medium ${
                isListening
                  ? 'bg-red-500 hover:bg-red-600 text-white'
                  : 'bg-blue-500 hover:bg-blue-600 text-white'
              }`}
            >
              {isListening ? 'Stop Listening' : 'Start Listening'}
            </button>
            <KeyboardShortcut />
          </div>

          <div className="mb-4">
            <h2 className="text-xl font-semibold text-gray-700 mb-2">
              Voice Commands:
            </h2>
            <ul className="list-disc list-inside text-gray-600">
              <li>"Add task [task description]"</li>
              <li>"Clear tasks"</li>
              <li>"Complete all"</li>
              <li>"Show tasks" or "List tasks"</li>
            </ul>
          </div>

          <VoiceRecognition onCommand={handleCommand} isListening={isListening} />
          
          <div className="mt-6">
            <h2 className="text-xl font-semibold text-gray-700 mb-4">Tasks:</h2>
            <TaskList
              tasks={tasks}
              onToggleTask={toggleTask}
              onDeleteTask={deleteTask}
            />
          </div>
        </div>
      </div>
    </div>
  );
}