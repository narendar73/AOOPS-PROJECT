export function KeyboardShortcut() {
  return (
    <div className="flex items-center space-x-2 text-sm text-gray-500">
      <span>Press</span>
      <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded shadow-sm font-mono">
        Space
      </kbd>
      <span>to toggle listening</span>
    </div>
  );
}